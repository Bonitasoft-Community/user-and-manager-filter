/**
 * 
 */
package org.mycompany.filter;

import java.util.ArrayList;
import java.util.List;

import org.bonitasoft.engine.api.IdentityAPI;
import org.bonitasoft.engine.connector.ConnectorValidationException;
import org.bonitasoft.engine.filter.UserFilterException;
import org.bonitasoft.engine.identity.User;
import org.bonitasoft.engine.identity.UserNotFoundException;

/**
 * 
 */
public class UserAndManagersImpl extends AbstractUserAndManagersImpl {

	@Override
	public void validateInputParameters() throws ConnectorValidationException {

		// Check that provide user name really exist in Bonita BPM Engine
		// database

		String username = getUsername();

		try {
			getAPIAccessor().getIdentityAPI().getUserByUserName(username);
		} catch (UserNotFoundException e) {
			ConnectorValidationException connectorValidationException = new ConnectorValidationException(
					"User with username: "
							+ username
							+ " cannot be found in Bonita BPM Engine database. Cause: "
							+ e.getMessage());
			throw connectorValidationException;
		}
	}

	@Override
	public List<Long> filter(final String actorName) throws UserFilterException {
		List<Long> userListOfIds = new ArrayList<Long>();

		IdentityAPI identityAPI = getAPIAccessor().getIdentityAPI();

		try {
			User user = identityAPI.getUserByUserName(getUsername());
			buildList(userListOfIds, user, identityAPI);
		} catch (UserNotFoundException e) {
			throw new UserFilterException("Failed to find a user: "
					+ e.getMessage());
		}

		return userListOfIds;
	}

	private void buildList(List<Long> userListOfIds, User user,
			IdentityAPI identityAPI) throws UserNotFoundException {

		userListOfIds.add(user.getId());

		long managerId = user.getManagerUserId();

		if (managerId != 0) {
			User manager = identityAPI.getUser(managerId);
			buildList(userListOfIds, manager, identityAPI);
		}
	}

	@Override
	public boolean shouldAutoAssignTaskIfSingleResult() {
		// If this method returns true, the step will be assigned to
		// the user if there is only one result returned by the filter method
		return super.shouldAutoAssignTaskIfSingleResult();

	}

}
